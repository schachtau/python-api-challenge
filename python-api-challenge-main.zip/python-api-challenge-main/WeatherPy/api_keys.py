# OpenWeatherMap API Key
weather_api_key = "4d366a1dc5d891fab467cc4f83f894f2"

# Geoapify API Key
geoapify_key = "1a6a1c61dc5045d5930fc2e04ce0d442"
